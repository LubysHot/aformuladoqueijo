<?php
/**
 * Banner ilustrado (SVG) do rato empreendedor — tema queijo + dinheiro.
 * Se existir uma imagem em uploads/banner.(jpg|png|webp), ela é usada no lugar do desenho.
 */
$banner_img = banner_image_url();
?>
<?php if ($banner_img): ?>
  <img class="hero-banner-img" src="<?= e($banner_img) ?>" alt="">
<?php else: ?>
<svg class="hero-banner-svg" viewBox="0 0 760 520" preserveAspectRatio="xMaxYMid meet" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Rato empreendedor com queijo e dinheiro">
  <defs>
    <radialGradient id="afqGlow" cx="55%" cy="42%" r="60%">
      <stop offset="0%" stop-color="#F5C518" stop-opacity="0.55"/>
      <stop offset="45%" stop-color="#7a5f00" stop-opacity="0.25"/>
      <stop offset="100%" stop-color="#000" stop-opacity="0"/>
    </radialGradient>
    <linearGradient id="afqFur" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#c9c2b6"/>
      <stop offset="60%" stop-color="#9a9186"/>
      <stop offset="100%" stop-color="#6c6459"/>
    </linearGradient>
    <linearGradient id="afqSnout" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#e8e2d6"/>
      <stop offset="100%" stop-color="#b7ad9f"/>
    </linearGradient>
    <linearGradient id="afqCheese" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#FFE06A"/>
      <stop offset="55%" stop-color="#F5C518"/>
      <stop offset="100%" stop-color="#E0A800"/>
    </linearGradient>
    <linearGradient id="afqCoin" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#FFE06A"/>
      <stop offset="100%" stop-color="#D89A00"/>
    </linearGradient>
    <linearGradient id="afqSuit" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#1b1b1b"/>
      <stop offset="100%" stop-color="#050505"/>
    </linearGradient>
    <linearGradient id="afqLens" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#2a2a2a"/>
      <stop offset="50%" stop-color="#0a0a0a"/>
      <stop offset="52%" stop-color="#F5C518" stop-opacity="0.5"/>
      <stop offset="60%" stop-color="#0a0a0a"/>
    </linearGradient>
  </defs>

  <!-- brilho dourado de fundo -->
  <circle cx="470" cy="235" r="300" fill="url(#afqGlow)"/>

  <!-- bokeh de "buracos de queijo" -->
  <g fill="#F5C518" opacity="0.10">
    <circle cx="150" cy="120" r="9"/><circle cx="250" cy="70" r="6"/>
    <circle cx="620" cy="90" r="11"/><circle cx="700" cy="200" r="7"/>
    <circle cx="90" cy="300" r="8"/><circle cx="680" cy="380" r="9"/>
  </g>

  <!-- moedas de ouro -->
  <g>
    <ellipse cx="150" cy="470" rx="66" ry="20" fill="url(#afqCoin)"/>
    <ellipse cx="150" cy="454" rx="66" ry="20" fill="url(#afqCoin)"/>
    <ellipse cx="150" cy="438" rx="66" ry="20" fill="url(#afqCoin)"/>
    <ellipse cx="150" cy="422" rx="60" ry="18" fill="#FFE894"/>
    <text x="150" y="429" font-family="Poppins,Arial,sans-serif" font-size="22" font-weight="800" fill="#9a6b00" text-anchor="middle">$</text>
    <ellipse cx="250" cy="486" rx="46" ry="14" fill="url(#afqCoin)"/>
    <ellipse cx="250" cy="476" rx="46" ry="14" fill="#FFE894"/>
    <text x="250" y="482" font-family="Poppins,Arial,sans-serif" font-size="15" font-weight="800" fill="#9a6b00" text-anchor="middle">$</text>
  </g>

  <!-- fatia de queijo -->
  <g transform="rotate(-8 300 430)">
    <path d="M215 470 L390 430 L390 500 Z" fill="url(#afqCheese)" stroke="#E0A800" stroke-width="2"/>
    <path d="M215 470 L390 430 L390 442 L228 478 Z" fill="#FFF0A8" opacity="0.6"/>
    <circle cx="300" cy="468" r="9" fill="#E0A800" opacity="0.8"/>
    <circle cx="345" cy="458" r="6" fill="#E0A800" opacity="0.8"/>
    <circle cx="360" cy="480" r="5" fill="#E0A800" opacity="0.8"/>
  </g>

  <!-- terno / ombros -->
  <path d="M300 520 Q320 400 470 400 Q620 400 640 520 Z" fill="url(#afqSuit)"/>
  <!-- camisa + gravata dourada -->
  <path d="M430 405 L470 470 L510 405 Z" fill="#efe9dc"/>
  <path d="M470 405 L484 440 L470 505 L456 440 Z" fill="url(#afqCheese)"/>
  <!-- lapelas -->
  <path d="M430 405 L400 520 L440 470 Z" fill="#0a0a0a"/>
  <path d="M510 405 L540 520 L500 470 Z" fill="#0a0a0a"/>

  <!-- cauda -->
  <path d="M600 470 Q700 450 690 360 Q684 300 620 300" fill="none" stroke="#8a8175" stroke-width="14" stroke-linecap="round" opacity="0.85"/>

  <!-- orelhas -->
  <circle cx="392" cy="150" r="54" fill="url(#afqFur)"/>
  <circle cx="392" cy="150" r="30" fill="#d7a8a0"/>
  <circle cx="548" cy="150" r="54" fill="url(#afqFur)"/>
  <circle cx="548" cy="150" r="30" fill="#d7a8a0"/>

  <!-- cabeça -->
  <ellipse cx="470" cy="250" rx="118" ry="108" fill="url(#afqFur)"/>
  <!-- rim light dourado -->
  <path d="M470 142 A118 108 0 0 1 588 250" fill="none" stroke="#F5C518" stroke-width="4" opacity="0.55" stroke-linecap="round"/>

  <!-- focinho -->
  <ellipse cx="470" cy="302" rx="66" ry="52" fill="url(#afqSnout)"/>
  <ellipse cx="470" cy="330" rx="17" ry="12" fill="#2a2320"/>
  <path d="M470 342 L470 356" stroke="#5c554d" stroke-width="3" stroke-linecap="round"/>

  <!-- bigodes -->
  <g stroke="#efe9dc" stroke-width="2.4" stroke-linecap="round" opacity="0.9">
    <path d="M420 316 L330 300"/><path d="M420 326 L332 330"/><path d="M420 336 L340 358"/>
    <path d="M520 316 L610 300"/><path d="M520 326 L608 330"/><path d="M520 336 L600 358"/>
  </g>

  <!-- óculos escuros -->
  <g>
    <rect x="392" y="212" width="74" height="50" rx="24" fill="url(#afqLens)" stroke="#F5C518" stroke-width="3"/>
    <rect x="474" y="212" width="74" height="50" rx="24" fill="url(#afqLens)" stroke="#F5C518" stroke-width="3"/>
    <path d="M466 232 Q470 226 474 232" fill="none" stroke="#F5C518" stroke-width="4"/>
    <path d="M392 224 L360 214" stroke="#F5C518" stroke-width="4" stroke-linecap="round"/>
    <path d="M548 224 L580 214" stroke="#F5C518" stroke-width="4" stroke-linecap="round"/>
    <path d="M402 236 L420 230" stroke="#fff" stroke-width="3" opacity="0.5" stroke-linecap="round"/>
    <path d="M484 236 L502 230" stroke="#fff" stroke-width="3" opacity="0.5" stroke-linecap="round"/>
  </g>
</svg>
<?php endif; ?>
