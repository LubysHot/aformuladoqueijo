<?php
/**
 * Helpers de autenticação, segurança e utilidades.
 */
require_once __DIR__ . '/db.php';

/* ---------------- Escapes / segurança ---------------- */

function e(?string $s): string {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

function redirect(string $path): void {
    header('Location: ' . $path);
    exit;
}

/** Token CSRF por sessão. */
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string {
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function csrf_check(): void {
    $ok = isset($_POST['csrf']) && hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf']);
    if (!$ok) {
        http_response_code(419);
        die('Sessão expirada. Volte e tente novamente.');
    }
}

/* ---------------- Autenticação ---------------- */

function current_user(): ?array {
    if (empty($_SESSION['uid'])) return null;
    static $cache = null;
    if ($cache !== null) return $cache;
    $cache = q1('SELECT * FROM users WHERE id = ?', [$_SESSION['uid']]);
    return $cache;
}

function is_logged_in(): bool { return current_user() !== null; }

function is_admin(): bool {
    $u = current_user();
    return $u && $u['role'] === 'admin';
}

function is_active_member(): bool {
    $u = current_user();
    return $u && (int)$u['is_active'] === 1;
}

/** Faz login. Retorna true/false. */
function attempt_login(string $email, string $password): bool {
    $u = q1('SELECT * FROM users WHERE email = ?', [strtolower(trim($email))]);
    if (!$u || !password_verify($password, $u['password_hash'])) {
        return false;
    }
    session_regenerate_id(true);
    $_SESSION['uid'] = $u['id'];
    return true;
}

function logout(): void {
    $_SESSION = [];
    session_destroy();
}

/** Bloqueia acesso de quem não está logado. */
function require_login(): void {
    if (!is_logged_in()) redirect(BASE_URL . '/login.php');
}

/** Exige membro ativo (login liberado). */
function require_active_member(): void {
    require_login();
    if (!is_active_member() && !is_admin()) {
        redirect(BASE_URL . '/bloqueado.php');
    }
}

/** Exige administrador. */
function require_admin(): void {
    require_login();
    if (!is_admin()) {
        http_response_code(403);
        die('Acesso restrito ao administrador.');
    }
}

/* ---------------- Conteúdo ---------------- */

function get_modules(bool $only_published = true): array {
    $sql = 'SELECT m.*, (SELECT COUNT(*) FROM lessons l WHERE l.module_id = m.id'
         . ($only_published ? ' AND l.is_published = 1' : '') . ') AS lesson_count
            FROM modules m';
    if ($only_published) $sql .= ' WHERE m.is_published = 1';
    $sql .= ' ORDER BY m.position ASC, m.id ASC';
    return qall($sql);
}

function get_module(int $id): ?array {
    return q1('SELECT * FROM modules WHERE id = ?', [$id]);
}

function get_lessons(int $module_id, bool $only_published = true): array {
    $sql = 'SELECT * FROM lessons WHERE module_id = ?';
    if ($only_published) $sql .= ' AND is_published = 1';
    $sql .= ' ORDER BY position ASC, id ASC';
    return qall($sql, [$module_id]);
}

function get_lesson(int $id): ?array {
    return q1('SELECT * FROM lessons WHERE id = ?', [$id]);
}

/** Progresso de aulas concluídas do usuário atual (array de lesson_id). */
function get_completed_lessons(int $user_id): array {
    $rows = qall('SELECT lesson_id FROM lesson_progress WHERE user_id = ? AND completed = 1', [$user_id]);
    return array_map(fn($r) => (int)$r['lesson_id'], $rows);
}

/* ---------------- Vídeo (embed) ---------------- */

/** Transforma uma URL de vídeo no HTML do player. */
function video_player_html(array $lesson): string {
    $type = $lesson['video_type'];
    $url  = $lesson['video_url'];

    if ($type === 'youtube') {
        $id = youtube_id($url);
        if ($id) {
            $origin = preg_replace('~^(https?://[^/]+).*~', '$1', BASE_URL);
            return '<iframe id="afqPlayer" src="https://www.youtube.com/embed/' . e($id)
                 . '?rel=0&modestbranding=1&enablejsapi=1&origin=' . rawurlencode($origin) . '" '
                 . 'title="' . e($lesson['title']) . '" frameborder="0" allowfullscreen '
                 . 'allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"></iframe>';
        }
    }
    if ($type === 'vimeo') {
        $id = vimeo_id($url);
        if ($id) {
            return '<iframe id="afqPlayer" src="https://player.vimeo.com/video/' . e($id) . '" '
                 . 'title="' . e($lesson['title']) . '" frameborder="0" allowfullscreen '
                 . 'allow="autoplay; fullscreen; picture-in-picture"></iframe>';
        }
    }
    // direct ou upload -> <video>
    $src = $url;
    if ($type === 'upload') {
        $src = BASE_URL . '/uploads/videos/' . rawurlencode(basename($url));
    }
    return '<video id="afqPlayer" controls controlslist="nodownload" preload="metadata" src="' . e($src) . '"></video>';
}

function youtube_id(string $url): ?string {
    if (preg_match('~(?:youtube\.com/(?:watch\?v=|embed/|shorts/)|youtu\.be/)([A-Za-z0-9_-]{11})~', $url, $m)) {
        return $m[1];
    }
    if (preg_match('~^[A-Za-z0-9_-]{11}$~', trim($url))) return trim($url);
    return null;
}

function vimeo_id(string $url): ?string {
    if (preg_match('~vimeo\.com/(?:video/)?(\d+)~', $url, $m)) return $m[1];
    if (preg_match('~^\d+$~', trim($url))) return trim($url);
    return null;
}

/* ---------------- Upload de arquivos ---------------- */

/**
 * Processa upload. $kind = 'covers' | 'videos' | 'avatars'.
 * Retorna o nome do arquivo salvo (não o caminho) ou null.
 */
function handle_upload(string $field, string $kind, array $allowed_ext): ?string {
    if (empty($_FILES[$field]) || $_FILES[$field]['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    $f = $_FILES[$field];
    if ($f['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Falha no upload (código ' . $f['error'] . ').');
    }
    $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed_ext, true)) {
        throw new RuntimeException('Tipo de arquivo não permitido: .' . $ext);
    }
    $dir = UPLOAD_PATH . '/' . $kind;
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    $name = $kind . '_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    if (!move_uploaded_file($f['tmp_name'], $dir . '/' . $name)) {
        throw new RuntimeException('Não foi possível salvar o arquivo enviado.');
    }
    return $name;
}

/** Retorna a URL do banner enviado (uploads/banner.*) ou null. */
function banner_image_url(): ?string {
    foreach (['jpg','jpeg','png','webp'] as $ext) {
        if (is_file(UPLOAD_PATH . '/banner.' . $ext)) {
            return BASE_URL . '/uploads/banner.' . $ext;
        }
    }
    return null;
}

/** Retorna a URL do banner da tela de login (uploads/login.*) ou null. */
function login_image_url(): ?string {
    foreach (['jpg','jpeg','png','webp'] as $ext) {
        if (is_file(UPLOAD_PATH . '/login.' . $ext)) {
            return BASE_URL . '/uploads/login.' . $ext;
        }
    }
    return null;
}

/** Resolve a URL pública de uma capa (upload ou URL externa). */
function cover_url(?string $cover): ?string {
    if (!$cover) return null;
    if (preg_match('~^https?://~', $cover)) return $cover;
    return BASE_URL . '/uploads/covers/' . rawurlencode($cover);
}

/** Mensagens flash simples. */
function flash(string $msg, string $type = 'ok'): void {
    $_SESSION['flash'][] = ['msg' => $msg, 'type' => $type];
}
function get_flashes(): array {
    $f = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $f;
}
