<?php
/**
 * Conexão com o banco (PDO) + helpers de query.
 */
require_once __DIR__ . '/../config.php';

function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            die('<div style="font-family:sans-serif;background:#000;color:#F5C518;padding:40px;text-align:center">'
              . '<h1>🧀 Erro de conexão com o banco</h1>'
              . '<p>Confira os dados em <b>config.php</b> (DB_NAME, DB_USER, DB_PASS, DB_HOST).</p>'
              . '<p style="color:#888">Se o site ainda não foi instalado, acesse <b>instalar.php</b>.</p>'
              . '</div>');
        }
    }
    return $pdo;
}

/** Executa uma query preparada e retorna o statement. */
function q(string $sql, array $params = []): PDOStatement {
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt;
}

/** Retorna uma única linha (ou null). */
function q1(string $sql, array $params = []): ?array {
    $row = q($sql, $params)->fetch();
    return $row === false ? null : $row;
}

/** Retorna todas as linhas. */
function qall(string $sql, array $params = []): array {
    return q($sql, $params)->fetchAll();
}

/** Verifica se as tabelas já existem (site instalado). */
function is_installed(): bool {
    try {
        db()->query('SELECT 1 FROM users LIMIT 1');
        return true;
    } catch (Throwable $e) {
        return false;
    }
}
