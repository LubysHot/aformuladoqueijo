</div><!-- /wrap -->
<footer class="footer">
  🧀 <b><?= e(SITE_NAME) ?></b> — área de membros exclusiva. © <?= date('Y') ?>. Todos os direitos reservados.
</footer>
<script src="<?= e(BASE_URL) ?>/assets/js/app.js"></script>
</body>
</html>
