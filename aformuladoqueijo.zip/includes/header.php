<?php
require_once __DIR__ . '/functions.php';
$u = current_user();
$page_title = $page_title ?? SITE_NAME;
?><!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($page_title) ?> · <?= e(SITE_NAME) ?></title>
<meta name="theme-color" content="#000000">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&family=Cinzel:wght@600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= e(BASE_URL) ?>/assets/css/style.css">
<link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🧀</text></svg>">
</head>
<body>
<div class="wrap">
<?php if (!empty($show_topbar)): ?>
<a href="<?= e(BASE_URL) ?>/perfil.php" class="fab-avatar" title="Meu perfil" aria-label="Meu perfil">
  <?= e(mb_strtoupper(mb_substr($u['display_name'] ?? 'A', 0, 1))) ?>
</a>
<?php endif; ?>
<?php foreach (get_flashes() as $f): ?>
  <div class="alert alert-<?= $f['type']==='error'?'error':'ok' ?>" style="max-width:1136px;margin:16px auto 0"><?= e($f['msg']) ?></div>
<?php endforeach; ?>
