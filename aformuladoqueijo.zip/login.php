<?php
require_once __DIR__ . '/includes/functions.php';

if (!is_installed()) { redirect(BASE_URL . '/instalar.php'); }
if (is_logged_in()) { redirect(BASE_URL . '/index.php'); }

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $email = $_POST['email'] ?? '';
    $pass  = $_POST['password'] ?? '';
    if (attempt_login($email, $pass)) {
        redirect(BASE_URL . '/index.php');
    }
    $error = 'Email ou senha incorretos. Verifique e tente de novo.';
}
$login_img = login_image_url();
?><!DOCTYPE html>
<html lang="pt-BR"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Entrar — <?= e(SITE_NAME) ?></title>
<meta name="theme-color" content="#000000">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= e(BASE_URL) ?>/assets/css/style.css">
<link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🧀</text></svg>">
</head><body>
<div class="login-page">
  <div class="login-hero<?= $login_img ? ' has-photo' : '' ?>"<?= $login_img ? ' style="background-image:url(\'' . e($login_img) . '\')"' : '' ?>>
    <?php if ($login_img): ?><span class="login-hero-fade"></span><?php endif; ?>
    <div class="login-hero-content">
      <h1>Bem-vindo à <span class="hl">Fórmula</span>.<br>Caçe o queijo. 🧀</h1>
      <p>A mentoria de quem saiu do zero e aprendeu a farejar oportunidades, atrair dinheiro e multiplicar resultados. Seu acesso é exclusivo — feito para quem entrou pra valer.</p>
    </div>
    <?php if (!$login_img): ?><div class="big-cheese">🧀</div><?php endif; ?>
  </div>

  <div class="login-form-side">
    <div class="login-card">
      <h2>Entrar na área de membros</h2>
      <p class="sub">Acesso liberado apenas para alunos da mentoria.</p>

      <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>

      <form method="post">
        <?= csrf_field() ?>
        <div class="field">
          <label>Email</label>
          <input type="email" name="email" required autofocus placeholder="seu@email.com" value="<?= e($_POST['email'] ?? '') ?>">
        </div>
        <div class="field">
          <label>Senha</label>
          <input type="password" name="password" required placeholder="••••••••">
        </div>
        <button class="btn btn-gold btn-block" style="margin-top:6px">ENTRAR 🧀</button>
      </form>

      <p style="color:var(--muted-2);font-size:13px;margin-top:22px;line-height:1.6">
        Ainda não é aluno? O acesso é liberado manualmente após a compra.<br>
        Problemas para entrar? Fale com o suporte da mentoria.
      </p>
    </div>
  </div>
</div>
</body></html>
