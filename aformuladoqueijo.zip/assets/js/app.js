/* A Fórmula do Queijo — interações */
(function () {
  // Carrossel: setas
  document.querySelectorAll('[data-carousel]').forEach(function (car) {
    var track = car.querySelector('.track');
    var left = car.querySelector('.arrow.left');
    var right = car.querySelector('.arrow.right');
    if (!track) return;
    var step = 260;
    if (left) left.addEventListener('click', function () { track.scrollBy({ left: -step * 2, behavior: 'smooth' }); });
    if (right) right.addEventListener('click', function () { track.scrollBy({ left: step * 2, behavior: 'smooth' }); });
  });

  // Fecha menu do usuário ao clicar fora
  document.addEventListener('click', function (ev) {
    var menu = document.getElementById('userMenu');
    var panel = document.getElementById('userMenuPanel');
    if (menu && panel && !menu.contains(ev.target)) panel.hidden = true;
  });

  // Modais (admin)
  window.openModal = function (id) {
    var m = document.getElementById(id);
    if (m) m.classList.add('open');
  };
  window.closeModal = function (id) {
    var m = document.getElementById(id);
    if (m) m.classList.remove('open');
  };
  document.querySelectorAll('.modal-back').forEach(function (mb) {
    mb.addEventListener('click', function (e) { if (e.target === mb) mb.classList.remove('open'); });
  });

  // Confirmação em ações destrutivas
  document.querySelectorAll('form[data-confirm]').forEach(function (f) {
    f.addEventListener('submit', function (e) {
      if (!confirm(f.getAttribute('data-confirm'))) e.preventDefault();
    });
  });

  // Mostra/oculta campos de vídeo conforme o tipo (admin)
  document.querySelectorAll('[data-video-type]').forEach(function (sel) {
    function upd() {
      var box = document.getElementById(sel.getAttribute('data-video-type'));
      if (!box) return;
      var isUpload = sel.value === 'upload';
      box.querySelectorAll('[data-when-upload]').forEach(function (el) { el.hidden = !isUpload; });
      box.querySelectorAll('[data-when-link]').forEach(function (el) { el.hidden = isUpload; });
    }
    sel.addEventListener('change', upd); upd();
  });
})();
