<?php
require_once __DIR__ . '/includes/functions.php';
logout();
redirect(BASE_URL . '/login.php');
