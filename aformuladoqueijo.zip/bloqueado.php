<?php
require_once __DIR__ . '/includes/functions.php';
require_login();
$u = current_user();
$page_title = 'Acesso pausado';
require __DIR__ . '/includes/header.php';
?>
<div class="page" style="max-width:560px;text-align:center;padding-top:60px">
  <div style="font-size:70px">🔒🧀</div>
  <h1 style="font-size:28px;margin:14px 0 10px">Seu acesso está pausado</h1>
  <p style="color:var(--muted);line-height:1.7">Olá, <?= e($u['display_name']) ?>. Sua conta existe, mas o acesso à área de membros está temporariamente desativado. Se você já é aluno da mentoria, fale com o suporte para reativar.</p>
  <a class="btn btn-ghost" style="margin-top:18px" href="<?= e(BASE_URL) ?>/logout.php">Sair</a>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
