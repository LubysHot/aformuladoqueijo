<?php
require_once __DIR__ . '/includes/functions.php';
if (!is_installed()) { redirect(BASE_URL . '/instalar.php'); }
require_login();

$u = current_user();

// Estatísticas de progresso
$total_lessons = (int)q1('SELECT COUNT(*) c FROM lessons WHERE is_published=1')['c'];
$total_modules = (int)q1('SELECT COUNT(*) c FROM modules WHERE is_published=1')['c'];
$done = (int)q1('SELECT COUNT(*) c FROM lesson_progress WHERE user_id=? AND completed=1', [$u['id']])['c'];
$pct = $total_lessons ? round($done / $total_lessons * 100) : 0;

$page_title = 'Meu Perfil';
$show_topbar = true;
require __DIR__ . '/includes/header.php';
?>
<div class="page" style="max-width:840px">
  <div class="breadcrumb"><a href="<?= e(BASE_URL) ?>/index.php">🏠 Meus Módulos</a> &nbsp;›&nbsp; Meu Perfil</div>

  <div class="profile-hero">
    <div class="big-avatar"><?= e(mb_strtoupper(mb_substr($u['display_name'], 0, 1))) ?></div>
    <div>
      <h1><?= e($u['display_name']) ?></h1>
      <div class="email"><?= e($u['email']) ?></div>
    </div>
    <div style="flex:1"></div>
    <?php if (is_admin()): ?>
      <a class="btn btn-ghost" href="<?= e(BASE_URL) ?>/admin/index.php">🛠️ Painel Admin</a>
    <?php endif; ?>
  </div>

  <!-- Informações da conta -->
  <div class="info-grid">
    <div class="info-item"><div class="k">Nível de acesso</div><div class="v gold"><?= is_admin() ? 'Administrador' : 'Aluno' ?></div></div>
    <div class="info-item"><div class="k">Status</div><div class="v" style="color:<?= $u['is_active']?'#9bffb8':'#ff9b9b' ?>"><?= $u['is_active'] ? 'Ativo ✅' : 'Pausado' ?></div></div>
    <div class="info-item"><div class="k">Membro desde</div><div class="v"><?= e(date('d/m/Y', strtotime($u['created_at']))) ?></div></div>
    <div class="info-item"><div class="k">Módulos disponíveis</div><div class="v"><?= $total_modules ?></div></div>
  </div>

  <!-- Progresso -->
  <div class="panel" style="background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:22px;margin-bottom:22px">
    <h3 style="margin:0 0 14px;font-size:16px;font-weight:700">📈 Seu progresso na mentoria</h3>
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">
      <span style="color:var(--muted);font-size:14px"><b style="color:var(--gold-2);font-size:18px"><?= $done ?></b> de <?= $total_lessons ?> aulas concluídas</span>
      <span style="color:var(--gold-2);font-weight:800;font-size:20px"><?= $pct ?>%</span>
    </div>
    <div class="pbar" style="height:10px;border-radius:6px;background:var(--surface-3)"><i style="display:block;height:100%;background:linear-gradient(90deg,var(--gold-2),var(--orange));width:<?= $pct ?>%"></i></div>
    <p style="color:var(--muted-2);font-size:13px;margin:12px 0 0">Continue caçando 🧀 — cada aula concluída te deixa mais perto do resultado.</p>
  </div>

  <!-- Informações importantes da mentoria -->
  <div class="panel" style="background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:22px;margin-bottom:22px">
    <h3 style="margin:0 0 16px;font-size:16px;font-weight:700">🧀 Informações importantes</h3>
    <ul class="note-list">
      <li><span class="ic">🎯</span><span><b>Assista na ordem.</b> Os módulos foram pensados numa sequência — comece pelo "Comece Por Aqui" e siga a jornada.</span></li>
      <li><span class="ic">✅</span><span><b>Marque suas aulas.</b> Ao terminar um vídeo, a aula é marcada como concluída automaticamente (ou você pode marcar manualmente).</span></li>
      <li><span class="ic">🔒</span><span><b>Acesso pessoal e intransferível.</b> Seu login é individual. Não compartilhe — isso protege seu acesso e o conteúdo da mentoria.</span></li>
      <li><span class="ic">💬</span><span><b>Suporte.</b> Dúvidas sobre pagamento ou acesso? Fale com o suporte da mentoria pelo canal informado na sua compra.</span></li>
      <li><span class="ic">🐭</span><span><b>Bons estudos!</b> Aplique o que aprender. O queijo é de quem age. 💰</span></li>
    </ul>
  </div>

  <!-- Ações -->
  <div style="display:flex;gap:12px;flex-wrap:wrap">
    <a class="btn btn-gold" href="<?= e(BASE_URL) ?>/index.php">🧀 Voltar aos módulos</a>
    <a class="btn btn-danger" href="<?= e(BASE_URL) ?>/logout.php">🚪 Sair da conta</a>
  </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
