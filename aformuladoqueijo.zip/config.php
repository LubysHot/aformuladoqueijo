<?php
/**
 * ============================================================
 *  A FÓRMULA DO QUEIJO — Configuração
 * ============================================================
 *  >>> EDITE APENAS OS 4 VALORES ABAIXO (dados do banco MySQL).
 *  Você cria o banco no painel da Hostinger (hPanel > Bancos MySQL),
 *  e copia aqui o nome do banco, usuário, senha e host.
 * ============================================================
 */

// ---- Dados do banco de dados MySQL (Hostinger) ----
define('DB_HOST', 'localhost');            // Normalmente "localhost" na Hostinger
define('DB_NAME', 'SEU_BANCO_AQUI');       // Nome do banco criado no hPanel
define('DB_USER', 'SEU_USUARIO_AQUI');     // Usuário do banco
define('DB_PASS', 'SUA_SENHA_AQUI');       // Senha do banco

// ---- Configurações do site (pode personalizar) ----
define('SITE_NAME', 'A Fórmula do Queijo');
define('SITE_TAGLINE', 'Caçe o queijo. Multiplique o dinheiro.');

// Tamanho máximo de upload de vídeo em MB (a hospedagem também limita)
define('MAX_VIDEO_MB', 500);

// ============================================================
//  NÃO PRECISA MEXER DAQUI PARA BAIXO
// ============================================================

// Detecta a URL base automaticamente
$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host   = $_SERVER['HTTP_HOST'] ?? 'localhost';
$dir    = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
// Se estiver dentro da pasta /admin, sobe um nível para achar a raiz do site
if (basename($dir) === 'admin') {
    $dir = dirname($dir);
}
$dir = ($dir === '/' || $dir === '.') ? '' : $dir;
if (!defined('BASE_URL')) {
    define('BASE_URL', $scheme . '://' . $host . $dir);
}

// Caminhos no disco
define('ROOT_PATH', __DIR__);
define('UPLOAD_PATH', __DIR__ . '/uploads');

// Sessão segura
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => ($scheme === 'https'),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_name('AFQ_SESS');
    session_start();
}

date_default_timezone_set('America/Sao_Paulo');
mb_internal_encoding('UTF-8');
