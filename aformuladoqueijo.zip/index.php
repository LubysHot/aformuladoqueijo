<?php
require_once __DIR__ . '/includes/functions.php';

if (!is_installed()) { redirect(BASE_URL . '/instalar.php'); }
require_active_member();

$u = current_user();
$modules = get_modules(true);
$completed = get_completed_lessons((int)$u['id']);
$completed_set = array_flip($completed);

$page_title = 'Meus Módulos';
$show_topbar = true;
require __DIR__ . '/includes/header.php';
?>
<?php $has_photo = banner_image_url() !== null; ?>
<section class="member-hero has-banner <?= $has_photo ? 'banner-photo' : 'banner-art' ?>">
  <div class="hero-banner"><?php include __DIR__ . '/includes/banner.php'; ?></div>
  <span class="hero-fade"></span>
  <div class="inner">
    <div class="eyebrow">Seja bem-vindo(a), <?= e($u['display_name']) ?></div>
    <h1>Sua jornada dentro da <span style="color:var(--gold-2)">Fórmula do Queijo</span></h1>
    <p>Aqui você vai aprender, passo a passo, tudo que eu fiz para sair do absoluto zero e <b style="color:#fff;font-weight:700">transformar atenção em dinheiro</b> na internet, do jeito mais direto possível e sem enrolação.</p>
    <div class="hero-cta">Assista aos módulos abaixo ↓</div>
  </div>
</section>

<div class="section">
  <div class="section-head">
    <span class="bar"></span>
    <h2>Clique em um dos módulos abaixo para assistir às aulas</h2>
  </div>

  <?php if (!$modules): ?>
    <div class="empty">
      <div class="big">🧀</div>
      <p>Nenhum módulo publicado ainda.<br>
      <?php if (is_admin()): ?><a class="btn btn-gold btn-sm" style="margin-top:12px" href="<?= e(BASE_URL) ?>/admin/modulos.php">Criar meu primeiro módulo</a><?php endif; ?></p>
    </div>
  <?php else: ?>
  <div class="carousel" data-carousel>
    <button class="arrow left" aria-label="Anterior">‹</button>
    <div class="track">
      <?php foreach ($modules as $m):
        $total = (int)$m['lesson_count'];
        $lessons = get_lessons((int)$m['id'], true);
        $done = 0; foreach ($lessons as $l) { if (isset($completed_set[(int)$l['id']])) $done++; }
        $pct = $total ? round($done / $total * 100) : 0;
        $cover = cover_url($m['cover_url']);
      ?>
      <a class="module-card" href="<?= e(BASE_URL) ?>/modulo.php?id=<?= (int)$m['id'] ?>">
        <div class="module-poster <?= $cover ? 'has-cover' : 'gen' ?>">
          <?php if ($cover): ?>
            <img src="<?= e($cover) ?>" alt="<?= e($m['title']) ?>">
          <?php else: ?>
            <div class="content">
              <div class="label"><?= e($m['label'] ?: 'MÓDULO') ?></div>
              <div class="title"><?= e($m['title']) ?></div>
              <div class="author">A FÓRMULA DO QUEIJO</div>
            </div>
          <?php endif; ?>
          <span class="count"><?= $total ?> AULA<?= $total==1?'':'S' ?></span>
        </div>
        <div class="foot">
          <span class="prog"><?= $done ?>/<?= $total ?> concluídas</span>
          <span class="go">Assistir →</span>
        </div>
        <div class="pbar"><i style="width:<?= $pct ?>%"></i></div>
      </a>
      <?php endforeach; ?>
    </div>
    <button class="arrow right" aria-label="Próximo">›</button>
  </div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
