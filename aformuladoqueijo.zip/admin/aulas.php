<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../config.php';
if (!is_installed()) { redirect(BASE_URL . '/instalar.php'); }
require_admin();

$IMG_EXT = ['jpg','jpeg','png','webp','gif'];
$VID_EXT = ['mp4','webm','mov','m4v','ogg'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';
    $module_id = (int)($_POST['module_id'] ?? 0);

    if ($action === 'save') {
        $lid    = (int)($_POST['id'] ?? 0);
        $title  = trim($_POST['title'] ?? '');
        $desc   = trim($_POST['description'] ?? '');
        $vtype  = in_array($_POST['video_type'] ?? '', ['youtube','vimeo','direct','upload'], true) ? $_POST['video_type'] : 'youtube';
        $vurl   = trim($_POST['video_url'] ?? '');
        $dur    = (int)($_POST['duration_minutes'] ?? 0);
        $pos    = (int)($_POST['position'] ?? 0);
        $pub    = isset($_POST['is_published']) ? 1 : 0;
        $cover  = $_POST['current_cover'] ?? null;

        if ($title === '') { flash('Informe o título da aula.', 'error'); redirect(BASE_URL.'/admin/aulas.php?module_id='.$module_id); }

        try {
            // capa
            $upc = handle_upload('cover_file', 'covers', $IMG_EXT);
            if ($upc) $cover = $upc;
            // vídeo por upload
            if ($vtype === 'upload') {
                $upv = handle_upload('video_file', 'videos', $VID_EXT);
                if ($upv) { $vurl = $upv; }
                elseif ($lid === 0) { throw new RuntimeException('Envie o arquivo de vídeo ou escolha um tipo de link.'); }
            }
        } catch (Throwable $e) {
            flash($e->getMessage(), 'error'); redirect(BASE_URL.'/admin/aulas.php?module_id='.$module_id);
        }

        if ($vtype !== 'upload' && $vurl === '') {
            flash('Cole o link do vídeo.', 'error'); redirect(BASE_URL.'/admin/aulas.php?module_id='.$module_id);
        }

        if ($lid > 0) {
            q('UPDATE lessons SET title=?,description=?,cover_url=?,video_type=?,video_url=?,duration_minutes=?,position=?,is_published=?,updated_at=NOW() WHERE id=?',
              [$title,$desc,$cover,$vtype,$vurl,$dur,$pos,$pub,$lid]);
            flash('Aula atualizada! 🎬');
        } else {
            q('INSERT INTO lessons (module_id,title,description,cover_url,video_type,video_url,duration_minutes,position,is_published) VALUES (?,?,?,?,?,?,?,?,?)',
              [$module_id,$title,$desc,$cover,$vtype,$vurl,$dur,$pos,$pub]);
            flash('Aula adicionada! 🎬');
        }
        redirect(BASE_URL.'/admin/aulas.php?module_id='.$module_id);
    }

    if ($action === 'delete') {
        $lid = (int)($_POST['id'] ?? 0);
        q('DELETE FROM lessons WHERE id=?', [$lid]);
        flash('Aula excluída.');
        redirect(BASE_URL.'/admin/aulas.php?module_id='.$module_id);
    }
}

$modules = get_modules(false);
$module_id = (int)($_GET['module_id'] ?? ($modules[0]['id'] ?? 0));
$module = $module_id ? get_module($module_id) : null;
$lessons = $module ? get_lessons($module_id, false) : [];

$active = 'aulas';
$page_title = 'Aulas';
require __DIR__ . '/header.php';
?>
<div class="admin-topline">
  <div><h1>🎬 Aulas / Vídeos</h1><div class="muted">Adicione e organize as aulas de cada módulo.</div></div>
  <?php if ($module): ?>
  <button class="btn btn-gold" onclick="prepCreate();openModal('lesModal')">+ Nova aula</button>
  <?php endif; ?>
</div>

<div class="panel">
  <div class="field" style="max-width:420px;margin-bottom:0">
    <label>Escolha o módulo</label>
    <select onchange="location.href='<?= e(BASE_URL) ?>/admin/aulas.php?module_id='+this.value">
      <?php foreach ($modules as $m): ?>
        <option value="<?= (int)$m['id'] ?>" <?= $m['id']==$module_id?'selected':'' ?>><?= e(($m['label']?$m['label'].' · ':'').$m['title']) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
</div>

<?php if (!$module): ?>
  <div class="panel"><div class="empty"><div class="big">🧀</div><p>Crie um módulo primeiro em <a href="<?= e(BASE_URL) ?>/admin/modulos.php" style="color:var(--gold-2)">Módulos</a>.</p></div></div>
<?php else: ?>
<div class="panel">
  <h3><?= e($module['title']) ?> — <?= count($lessons) ?> aula<?= count($lessons)==1?'':'s' ?></h3>
  <?php if (!$lessons): ?>
    <div class="empty"><div class="big">🎬</div><p>Nenhuma aula neste módulo. Clique em <b>+ Nova aula</b>.</p></div>
  <?php else: ?>
  <table class="table">
    <thead><tr><th>#</th><th>Aula</th><th>Vídeo</th><th>Duração</th><th>Status</th><th></th></tr></thead>
    <tbody>
    <?php $i=1; foreach ($lessons as $l): ?>
      <tr>
        <td><?= (int)$l['position'] ?: $i ?></td>
        <td><b><?= e($l['title']) ?></b><?php if($l['description']): ?><br><small style="color:var(--muted)"><?= e(mb_strimwidth($l['description'],0,70,'…')) ?></small><?php endif; ?></td>
        <td><span class="tag member"><?= strtoupper(e($l['video_type'])) ?></span></td>
        <td><?= $l['duration_minutes'] ? (int)$l['duration_minutes'].' min' : '—' ?></td>
        <td><span class="tag <?= $l['is_published']?'on':'off' ?>"><?= $l['is_published']?'Publicada':'Oculta' ?></span></td>
        <td>
          <div class="row-actions">
            <button class="btn btn-dark btn-sm" onclick="editLesson(<?= e(json_encode([
              "id"=>(int)$l["id"],"title"=>$l["title"],"description"=>$l["description"],
              "video_type"=>$l["video_type"],"video_url"=>$l["video_url"],
              "duration_minutes"=>(int)$l["duration_minutes"],"position"=>(int)$l["position"],
              "is_published"=>(int)$l["is_published"],"cover"=>$l["cover_url"]
            ])) ?>)">✏️</button>
            <form method="post" data-confirm="Excluir esta aula?">
              <?= csrf_field() ?><input type="hidden" name="action" value="delete">
              <input type="hidden" name="id" value="<?= (int)$l['id'] ?>"><input type="hidden" name="module_id" value="<?= $module_id ?>">
              <button class="btn btn-danger btn-sm">🗑️</button>
            </form>
          </div>
        </td>
      </tr>
    <?php $i++; endforeach; ?>
    </tbody>
  </table>
  <?php endif; ?>
</div>

<!-- Modal aula -->
<div class="modal-back" id="lesModal">
  <div class="modal">
    <span class="close" onclick="closeModal('lesModal')">×</span>
    <h3 id="lesTitle">Nova aula</h3>
    <form method="post" enctype="multipart/form-data" id="lesForm">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" id="l_id" value="">
      <input type="hidden" name="module_id" value="<?= $module_id ?>">
      <input type="hidden" name="current_cover" id="l_current_cover" value="">

      <div class="field"><label>Título da aula *</label><input name="title" id="l_title" required placeholder="Ex: A oferta irresistível"></div>
      <div class="field"><label>Descrição</label><textarea name="description" id="l_description" placeholder="Resumo da aula"></textarea></div>

      <div class="grid-2">
        <div class="field">
          <label>Tipo de vídeo</label>
          <select name="video_type" id="l_video_type" data-video-type="videoBox">
            <option value="youtube">YouTube (link)</option>
            <option value="vimeo">Vimeo (link)</option>
            <option value="direct">Link direto (.mp4)</option>
            <option value="upload">Enviar arquivo</option>
          </select>
        </div>
        <div class="field"><label>Duração (min)</label><input type="number" name="duration_minutes" id="l_duration" value="0"></div>
      </div>

      <div id="videoBox">
        <div class="field" data-when-link>
          <label>Link do vídeo</label>
          <input name="video_url" id="l_video_url" placeholder="Cole aqui o link do YouTube/Vimeo/.mp4">
          <div class="hint">Ex: https://www.youtube.com/watch?v=XXXX</div>
        </div>
        <div class="field" data-when-upload hidden>
          <label>Arquivo de vídeo (MP4/WEBM)</label>
          <input type="file" name="video_file" accept="video/*">
          <div class="hint">Até <?= (int)MAX_VIDEO_MB ?>MB. Para vídeos grandes, prefira YouTube/Vimeo (mais rápido e leve).</div>
        </div>
      </div>

      <div class="grid-2">
        <div class="field"><label>Capa da aula (opcional)</label><input type="file" name="cover_file" accept="image/*"></div>
        <div class="field"><label>Ordem</label><input type="number" name="position" id="l_position" value="0"></div>
      </div>

      <label style="display:flex;align-items:center;gap:10px;margin:6px 0 18px;color:#ddd;font-size:14px">
        <input type="checkbox" name="is_published" id="l_published" checked style="width:auto"> Publicar (visível para os alunos)
      </label>
      <button class="btn btn-gold btn-block">Salvar aula 🎬</button>
    </form>
  </div>
</div>

<script>
function syncVideoBox(){ document.getElementById('l_video_type').dispatchEvent(new Event('change')); }
function prepCreate(){
  document.getElementById('lesForm').reset();
  document.getElementById('lesTitle').textContent='Nova aula';
  document.getElementById('l_id').value='';
  document.getElementById('l_current_cover').value='';
  document.getElementById('l_published').checked=true;
  syncVideoBox();
}
function editLesson(l){
  openModal('lesModal');
  document.getElementById('lesTitle').textContent='Editar aula';
  document.getElementById('l_id').value=l.id;
  document.getElementById('l_title').value=l.title||'';
  document.getElementById('l_description').value=l.description||'';
  document.getElementById('l_video_type').value=l.video_type||'youtube';
  document.getElementById('l_video_url').value=(l.video_type==='upload')?'':(l.video_url||'');
  document.getElementById('l_duration').value=l.duration_minutes||0;
  document.getElementById('l_position').value=l.position||0;
  document.getElementById('l_published').checked=!!l.is_published;
  document.getElementById('l_current_cover').value=l.cover||'';
  syncVideoBox();
}
</script>
<?php endif; ?>
<?php require __DIR__ . '/footer.php'; ?>
