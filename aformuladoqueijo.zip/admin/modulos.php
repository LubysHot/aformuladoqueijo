<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../config.php';
if (!is_installed()) { redirect(BASE_URL . '/instalar.php'); }
require_admin();

$IMG_EXT = ['jpg','jpeg','png','webp','gif'];

/* ---- Ações ---- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';

    if ($action === 'save') {
        $mid    = (int)($_POST['id'] ?? 0);
        $label  = trim($_POST['label'] ?? '');
        $title  = trim($_POST['title'] ?? '');
        $desc   = trim($_POST['description'] ?? '');
        $pos    = (int)($_POST['position'] ?? 0);
        $pub    = isset($_POST['is_published']) ? 1 : 0;
        $cover  = $_POST['current_cover'] ?? null;

        if ($title === '') { flash('Informe o título do módulo.', 'error'); redirect(BASE_URL.'/admin/modulos.php'); }

        try {
            $up = handle_upload('cover_file', 'covers', $IMG_EXT);
            if ($up) $cover = $up;
        } catch (Throwable $e) { flash($e->getMessage(), 'error'); redirect(BASE_URL.'/admin/modulos.php'); }

        if (!empty($_POST['cover_url_ext'])) $cover = trim($_POST['cover_url_ext']);

        if ($mid > 0) {
            q('UPDATE modules SET label=?,title=?,description=?,cover_url=?,position=?,is_published=?,updated_at=NOW() WHERE id=?',
              [$label,$title,$desc,$cover,$pos,$pub,$mid]);
            flash('Módulo atualizado! 🧀');
        } else {
            q('INSERT INTO modules (label,title,description,cover_url,position,is_published) VALUES (?,?,?,?,?,?)',
              [$label,$title,$desc,$cover,$pos,$pub]);
            flash('Módulo criado! 🧀');
        }
        redirect(BASE_URL.'/admin/modulos.php');
    }

    if ($action === 'delete') {
        $mid = (int)($_POST['id'] ?? 0);
        q('DELETE FROM modules WHERE id=?', [$mid]);
        flash('Módulo excluído.');
        redirect(BASE_URL.'/admin/modulos.php');
    }
}

$edit = null;
if (isset($_GET['edit'])) $edit = get_module((int)$_GET['edit']);

$modules = get_modules(false);

$active = 'modulos';
$page_title = 'Módulos';
require __DIR__ . '/header.php';
?>
<div class="admin-topline">
  <div><h1>🧀 Módulos</h1><div class="muted">Crie e organize os módulos da mentoria.</div></div>
  <button class="btn btn-gold" onclick="openModal('modModal'); document.getElementById('modForm').reset(); prepCreate();">+ Novo módulo</button>
</div>

<div class="panel">
  <?php if (!$modules): ?>
    <div class="empty"><div class="big">🧀</div><p>Nenhum módulo ainda. Clique em <b>+ Novo módulo</b>.</p></div>
  <?php else: ?>
  <table class="table">
    <thead><tr><th>Capa</th><th>Módulo</th><th>Aulas</th><th>Ordem</th><th>Status</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($modules as $m):
      $c = cover_url($m['cover_url']);
      $count = (int)q1('SELECT COUNT(*) c FROM lessons WHERE module_id=?',[$m['id']])['c'];
    ?>
      <tr>
        <td>
          <?php if ($c): ?><img class="thumb" src="<?= e($c) ?>" alt="">
          <?php else: ?><div class="thumb" style="display:grid;place-items:center;font-size:22px">🧀</div><?php endif; ?>
        </td>
        <td>
          <div style="font-size:11px;color:var(--gold-2);font-weight:700;letter-spacing:1px"><?= e($m['label']) ?></div>
          <b><?= e($m['title']) ?></b>
        </td>
        <td><a class="btn btn-dark btn-sm" href="<?= e(BASE_URL) ?>/admin/aulas.php?module_id=<?= (int)$m['id'] ?>"><?= $count ?> aula<?= $count==1?'':'s' ?> →</a></td>
        <td><?= (int)$m['position'] ?></td>
        <td><span class="tag <?= $m['is_published']?'on':'off' ?>"><?= $m['is_published']?'Publicado':'Oculto' ?></span></td>
        <td>
          <div class="row-actions">
            <button class="btn btn-dark btn-sm" onclick="editModule(<?= e(json_encode([
              "id"=>(int)$m["id"],"label"=>$m["label"],"title"=>$m["title"],
              "description"=>$m["description"],"position"=>(int)$m["position"],
              "is_published"=>(int)$m["is_published"],"cover"=>$m["cover_url"]
            ])) ?>)">✏️ Editar</button>
            <form method="post" data-confirm="Excluir este módulo e TODAS as suas aulas? Não dá pra desfazer.">
              <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$m['id'] ?>">
              <button class="btn btn-danger btn-sm">🗑️</button>
            </form>
          </div>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  <?php endif; ?>
</div>

<!-- Modal criar/editar -->
<div class="modal-back" id="modModal">
  <div class="modal">
    <span class="close" onclick="closeModal('modModal')">×</span>
    <h3 id="modTitle">Novo módulo</h3>
    <form method="post" enctype="multipart/form-data" id="modForm">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="save">
      <input type="hidden" name="id" id="f_id" value="">
      <input type="hidden" name="current_cover" id="f_current_cover" value="">
      <div class="grid-2">
        <div class="field"><label>Etiqueta (ex: MÓDULO 1)</label><input name="label" id="f_label" placeholder="MÓDULO 1"></div>
        <div class="field"><label>Ordem de exibição</label><input type="number" name="position" id="f_position" value="0"></div>
      </div>
      <div class="field"><label>Título do módulo *</label><input name="title" id="f_title" required placeholder="Ex: MENTALIDADE DE RATO"></div>
      <div class="field"><label>Descrição</label><textarea name="description" id="f_description" placeholder="Do que trata este módulo?"></textarea></div>
      <div class="field">
        <label>Capa do módulo (imagem)</label>
        <input type="file" name="cover_file" accept="image/*">
        <div class="hint">Recomendado: imagem vertical (proporção 3x4). JPG, PNG ou WEBP. Deixe vazio para usar a capa temática automática.</div>
      </div>
      <div class="field"><label>Ou cole a URL de uma imagem (opcional)</label><input name="cover_url_ext" id="f_cover_ext" placeholder="https://..."></div>
      <label style="display:flex;align-items:center;gap:10px;margin:6px 0 18px;color:#ddd;font-size:14px">
        <input type="checkbox" name="is_published" id="f_published" checked style="width:auto"> Publicar (visível para os alunos)
      </label>
      <button class="btn btn-gold btn-block">Salvar módulo 🧀</button>
    </form>
  </div>
</div>

<script>
function prepCreate(){
  document.getElementById('modTitle').textContent='Novo módulo';
  document.getElementById('f_id').value='';
  document.getElementById('f_current_cover').value='';
  document.getElementById('f_published').checked=true;
}
function editModule(m){
  openModal('modModal');
  document.getElementById('modTitle').textContent='Editar módulo';
  document.getElementById('f_id').value=m.id;
  document.getElementById('f_label').value=m.label||'';
  document.getElementById('f_title').value=m.title||'';
  document.getElementById('f_description').value=m.description||'';
  document.getElementById('f_position').value=m.position||0;
  document.getElementById('f_published').checked=!!m.is_published;
  document.getElementById('f_current_cover').value=m.cover||'';
  document.getElementById('f_cover_ext').value='';
}
</script>
<?php require __DIR__ . '/footer.php'; ?>
