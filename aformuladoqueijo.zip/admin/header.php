<?php
require_once __DIR__ . '/../includes/functions.php';
if (!is_installed()) { redirect(BASE_URL . '/instalar.php'); }
require_admin();
$u = current_user();
$active = $active ?? '';
$page_title = $page_title ?? 'Admin';
function navcls($name, $active){ return $name === $active ? 'active' : ''; }
?><!DOCTYPE html>
<html lang="pt-BR"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($page_title) ?> · Admin · <?= e(SITE_NAME) ?></title>
<meta name="theme-color" content="#000000">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= e(BASE_URL) ?>/assets/css/style.css">
<link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🧀</text></svg>">
</head><body>
<div class="admin-shell">
  <aside class="admin-side">
    <a href="<?= e(BASE_URL) ?>/admin/index.php" style="display:block;font-weight:800;font-size:16px;color:var(--gold-2);letter-spacing:.5px;margin-bottom:22px">Painel Admin</a>
    <nav class="admin-nav">
      <a class="<?= navcls('dashboard',$active) ?>" href="<?= e(BASE_URL) ?>/admin/index.php"><span class="ic">📊</span> Visão geral</a>
      <a class="<?= navcls('modulos',$active) ?>" href="<?= e(BASE_URL) ?>/admin/modulos.php"><span class="ic">🧀</span> Módulos</a>
      <a class="<?= navcls('aulas',$active) ?>" href="<?= e(BASE_URL) ?>/admin/aulas.php"><span class="ic">🎬</span> Aulas / Vídeos</a>
      <a class="<?= navcls('alunos',$active) ?>" href="<?= e(BASE_URL) ?>/admin/alunos.php"><span class="ic">👥</span> Alunos / Acessos</a>
      <div class="divider" style="height:1px;background:var(--border);margin:10px 6px"></div>
      <a href="<?= e(BASE_URL) ?>/index.php"><span class="ic">👁️</span> Ver o site</a>
      <a href="<?= e(BASE_URL) ?>/logout.php"><span class="ic">🚪</span> Sair</a>
    </nav>
  </aside>
  <main class="admin-main">
    <?php foreach (get_flashes() as $f): ?>
      <div class="alert alert-<?= $f['type']==='error'?'error':'ok' ?>"><?= e($f['msg']) ?></div>
    <?php endforeach; ?>
