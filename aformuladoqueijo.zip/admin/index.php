<?php
require_once __DIR__ . '/../includes/functions.php';
$active = 'dashboard';
$page_title = 'Visão geral';
require __DIR__ . '/header.php';

$n_modules = (int)q1('SELECT COUNT(*) c FROM modules')['c'];
$n_lessons = (int)q1('SELECT COUNT(*) c FROM lessons')['c'];
$n_members = (int)q1("SELECT COUNT(*) c FROM users WHERE role='member'")['c'];
$n_active  = (int)q1("SELECT COUNT(*) c FROM users WHERE role='member' AND is_active=1")['c'];
$recent = qall('SELECT * FROM users ORDER BY created_at DESC LIMIT 6');
?>
<div class="admin-topline">
  <div>
    <h1>Bem-vindo, <?= e($u['display_name']) ?> 🧀</h1>
    <div class="muted">Gerencie os módulos, vídeos e acessos da sua mentoria.</div>
  </div>
  <a class="btn btn-gold" href="<?= e(BASE_URL) ?>/admin/modulos.php">+ Novo módulo</a>
</div>

<div class="stat-grid">
  <div class="stat"><div class="big"><?= $n_modules ?></div><div class="lbl">🧀 Módulos</div></div>
  <div class="stat"><div class="big"><?= $n_lessons ?></div><div class="lbl">🎬 Aulas / vídeos</div></div>
  <div class="stat"><div class="big"><?= $n_members ?></div><div class="lbl">👥 Alunos cadastrados</div></div>
  <div class="stat"><div class="big"><?= $n_active ?></div><div class="lbl">✅ Acessos ativos</div></div>
</div>

<div class="panel">
  <h3>🚀 Atalhos rápidos</h3>
  <div class="row-actions">
    <a class="btn btn-dark" href="<?= e(BASE_URL) ?>/admin/modulos.php">🧀 Gerenciar módulos</a>
    <a class="btn btn-dark" href="<?= e(BASE_URL) ?>/admin/aulas.php">🎬 Adicionar aulas / vídeos</a>
    <a class="btn btn-dark" href="<?= e(BASE_URL) ?>/admin/alunos.php">👥 Liberar acesso de aluno</a>
    <a class="btn btn-ghost" href="<?= e(BASE_URL) ?>/index.php">👁️ Ver como fica pro aluno</a>
  </div>
</div>

<div class="panel">
  <h3>🆕 Últimos cadastros</h3>
  <?php if (!$recent): ?>
    <div class="empty"><p>Ninguém cadastrado ainda.</p></div>
  <?php else: ?>
  <table class="table">
    <thead><tr><th>Nome</th><th>Email</th><th>Tipo</th><th>Acesso</th></tr></thead>
    <tbody>
    <?php foreach ($recent as $r): ?>
      <tr>
        <td><?= e($r['display_name']) ?></td>
        <td style="color:var(--muted)"><?= e($r['email']) ?></td>
        <td><span class="tag <?= $r['role']==='admin'?'admin':'member' ?>"><?= $r['role']==='admin'?'Admin':'Aluno' ?></span></td>
        <td><span class="tag <?= $r['is_active']?'on':'off' ?>"><?= $r['is_active']?'Ativo':'Pausado' ?></span></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/footer.php'; ?>
