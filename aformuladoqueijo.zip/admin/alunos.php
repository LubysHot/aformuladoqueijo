<?php
require_once __DIR__ . '/../includes/functions.php';
if (!is_installed()) { redirect(BASE_URL . '/instalar.php'); }
require_admin();

$me = current_user();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $name  = trim($_POST['name'] ?? '');
        $email = strtolower(trim($_POST['email'] ?? ''));
        $pass  = $_POST['password'] ?? '';
        $role  = ($_POST['role'] ?? 'member') === 'admin' ? 'admin' : 'member';
        if ($name==='' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($pass) < 6) {
            flash('Preencha nome, email válido e senha (mín. 6 caracteres).', 'error');
        } elseif (q1('SELECT id FROM users WHERE email=?', [$email])) {
            flash('Já existe um usuário com esse email.', 'error');
        } else {
            q('INSERT INTO users (email,password_hash,display_name,role,is_active) VALUES (?,?,?,?,1)',
              [$email, password_hash($pass, PASSWORD_DEFAULT), $name, $role]);
            flash('Acesso criado para '.$name.'! 🧀 Já pode entrar com email e senha.');
        }
        redirect(BASE_URL.'/admin/alunos.php');
    }

    $target = (int)($_POST['id'] ?? 0);

    if ($action === 'toggle_active' && $target) {
        if ($target === (int)$me['id']) { flash('Você não pode pausar seu próprio acesso.', 'error'); }
        else { q('UPDATE users SET is_active = 1 - is_active WHERE id=?', [$target]); flash('Acesso atualizado.'); }
        redirect(BASE_URL.'/admin/alunos.php');
    }

    if ($action === 'toggle_role' && $target) {
        if ($target === (int)$me['id']) { flash('Você não pode alterar seu próprio nível.', 'error'); }
        else {
            $t = q1('SELECT * FROM users WHERE id=?', [$target]);
            $new = ($t && $t['role']==='admin') ? 'member' : 'admin';
            q('UPDATE users SET role=? WHERE id=?', [$new, $target]);
            flash('Nível alterado para '.($new==='admin'?'Administrador':'Aluno').'.');
        }
        redirect(BASE_URL.'/admin/alunos.php');
    }

    if ($action === 'reset_pass' && $target) {
        $pass = $_POST['new_password'] ?? '';
        if (strlen($pass) < 6) flash('A nova senha precisa de ao menos 6 caracteres.', 'error');
        else { q('UPDATE users SET password_hash=? WHERE id=?', [password_hash($pass, PASSWORD_DEFAULT), $target]); flash('Senha redefinida.'); }
        redirect(BASE_URL.'/admin/alunos.php');
    }

    if ($action === 'delete' && $target) {
        if ($target === (int)$me['id']) flash('Você não pode excluir a si mesmo.', 'error');
        else { q('DELETE FROM users WHERE id=?', [$target]); flash('Usuário excluído.'); }
        redirect(BASE_URL.'/admin/alunos.php');
    }
}

$users = qall('SELECT * FROM users ORDER BY role DESC, created_at DESC');

$active = 'alunos';
$page_title = 'Alunos';
require __DIR__ . '/header.php';
?>
<div class="admin-topline">
  <div><h1>👥 Alunos / Acessos</h1><div class="muted">Libere o acesso de quem pagou. Só quem está aqui consegue entrar.</div></div>
  <button class="btn btn-gold" onclick="openModal('newUserModal')">+ Liberar novo acesso</button>
</div>

<div class="panel">
  <table class="table">
    <thead><tr><th>Nome</th><th>Email</th><th>Nível</th><th>Acesso</th><th>Desde</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($users as $usr): $self = (int)$usr['id']===(int)$me['id']; ?>
      <tr>
        <td><b><?= e($usr['display_name']) ?></b><?= $self?' <span style="color:var(--muted-2);font-size:12px">(você)</span>':'' ?></td>
        <td style="color:var(--muted)"><?= e($usr['email']) ?></td>
        <td><span class="tag <?= $usr['role']==='admin'?'admin':'member' ?>"><?= $usr['role']==='admin'?'Admin':'Aluno' ?></span></td>
        <td><span class="tag <?= $usr['is_active']?'on':'off' ?>"><?= $usr['is_active']?'Ativo':'Pausado' ?></span></td>
        <td style="color:var(--muted);font-size:13px"><?= e(date('d/m/Y', strtotime($usr['created_at']))) ?></td>
        <td>
          <div class="row-actions">
            <?php if (!$self): ?>
            <form method="post" title="Ativar/pausar acesso">
              <?= csrf_field() ?><input type="hidden" name="action" value="toggle_active"><input type="hidden" name="id" value="<?= (int)$usr['id'] ?>">
              <button class="btn btn-dark btn-sm"><?= $usr['is_active']?'⏸️ Pausar':'▶️ Ativar' ?></button>
            </form>
            <form method="post" title="Promover/rebaixar" data-confirm="Alterar o nível de acesso deste usuário?">
              <?= csrf_field() ?><input type="hidden" name="action" value="toggle_role"><input type="hidden" name="id" value="<?= (int)$usr['id'] ?>">
              <button class="btn btn-dark btn-sm"><?= $usr['role']==='admin'?'⬇️ Tornar aluno':'⬆️ Tornar admin' ?></button>
            </form>
            <?php endif; ?>
            <button class="btn btn-dark btn-sm" onclick="resetPass(<?= (int)$usr["id"] ?>, <?= e(json_encode($usr["display_name"])) ?>)">🔑</button>
            <?php if (!$self): ?>
            <form method="post" data-confirm="Excluir este usuário definitivamente?">
              <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$usr['id'] ?>">
              <button class="btn btn-danger btn-sm">🗑️</button>
            </form>
            <?php endif; ?>
          </div>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>

<!-- Modal novo acesso -->
<div class="modal-back" id="newUserModal">
  <div class="modal">
    <span class="close" onclick="closeModal('newUserModal')">×</span>
    <h3>🧀 Liberar novo acesso</h3>
    <p style="color:var(--muted);font-size:14px;margin-top:-8px">Crie o login de um aluno que comprou a mentoria.</p>
    <form method="post">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="create">
      <div class="field"><label>Nome do aluno</label><input name="name" required placeholder="Nome completo"></div>
      <div class="field"><label>Email</label><input type="email" name="email" required placeholder="aluno@email.com"></div>
      <div class="grid-2">
        <div class="field"><label>Senha</label><input name="password" required minlength="6" placeholder="mín. 6 caracteres"></div>
        <div class="field"><label>Nível</label>
          <select name="role"><option value="member">Aluno</option><option value="admin">Administrador</option></select>
        </div>
      </div>
      <button class="btn btn-gold btn-block">Criar acesso 🚀</button>
    </form>
  </div>
</div>

<!-- Modal reset senha -->
<div class="modal-back" id="resetModal">
  <div class="modal">
    <span class="close" onclick="closeModal('resetModal')">×</span>
    <h3>🔑 Redefinir senha</h3>
    <p style="color:var(--muted);font-size:14px;margin-top:-8px" id="resetWho"></p>
    <form method="post">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="reset_pass">
      <input type="hidden" name="id" id="reset_id">
      <div class="field"><label>Nova senha</label><input name="new_password" required minlength="6" placeholder="mín. 6 caracteres"></div>
      <button class="btn btn-gold btn-block">Salvar nova senha</button>
    </form>
  </div>
</div>

<script>
function resetPass(id,name){
  document.getElementById('reset_id').value=id;
  document.getElementById('resetWho').textContent='Definir nova senha para '+name+'.';
  openModal('resetModal');
}
</script>
<?php require __DIR__ . '/footer.php'; ?>
