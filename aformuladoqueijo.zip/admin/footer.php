  </main>
</div>
<script src="<?= e(BASE_URL) ?>/assets/js/app.js"></script>
</body></html>
