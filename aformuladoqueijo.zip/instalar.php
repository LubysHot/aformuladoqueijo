<?php
/**
 * INSTALADOR — A Fórmula do Queijo
 * Acesse este arquivo no navegador uma única vez para preparar o site.
 * Ele cria as tabelas, popula os módulos de exemplo e cria o admin.
 */
require_once __DIR__ . '/includes/functions.php';

$step_error = '';
$done = false;

/* 1) Cria as tabelas (se ainda não existem) */
function create_schema(): void {
    $pdo = db();
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(190) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL,
        display_name VARCHAR(120) NOT NULL DEFAULT 'Aluno',
        avatar_url VARCHAR(255) NULL,
        role ENUM('admin','member') NOT NULL DEFAULT 'member',
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS modules (
        id INT AUTO_INCREMENT PRIMARY KEY,
        label VARCHAR(60) NOT NULL DEFAULT '',
        title VARCHAR(160) NOT NULL,
        description TEXT NULL,
        cover_url VARCHAR(255) NULL,
        position INT NOT NULL DEFAULT 0,
        is_published TINYINT(1) NOT NULL DEFAULT 1,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS lessons (
        id INT AUTO_INCREMENT PRIMARY KEY,
        module_id INT NOT NULL,
        title VARCHAR(190) NOT NULL,
        description TEXT NULL,
        cover_url VARCHAR(255) NULL,
        video_type ENUM('youtube','vimeo','direct','upload') NOT NULL DEFAULT 'youtube',
        video_url VARCHAR(500) NOT NULL DEFAULT '',
        duration_minutes INT NOT NULL DEFAULT 0,
        position INT NOT NULL DEFAULT 0,
        is_published TINYINT(1) NOT NULL DEFAULT 1,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX (module_id),
        FOREIGN KEY (module_id) REFERENCES modules(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS lesson_progress (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        lesson_id INT NOT NULL,
        completed TINYINT(1) NOT NULL DEFAULT 0,
        completed_at DATETIME NULL,
        UNIQUE KEY uniq_user_lesson (user_id, lesson_id),
        INDEX (user_id), INDEX (lesson_id),
        FOREIGN KEY (lesson_id) REFERENCES lessons(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

/* 2) Popula módulos + aulas de exemplo (apenas se a tabela estiver vazia) */
function seed_content(): void {
    if ((int)q1('SELECT COUNT(*) c FROM modules')['c'] > 0) return;

    $modules = [
        ['BOAS-VINDAS','Comece Por Aqui','Conheça a jornada, organize seus próximos passos e entre no jogo com clareza.',1],
        ['MÓDULO 1','MENTALIDADE DE RATO','Construa o mindset de quem reconhece valor, age rápido e aprende com o mercado.',2],
        ['MÓDULO 2','ONDE ESTÁ O QUEIJO','Aprenda a identificar problemas valiosos, demandas reais e oportunidades lucrativas.',3],
        ['MÓDULO 3','A CAÇADA','Transforme atenção em vendas com posicionamento, tráfego e uma oferta irresistível.',4],
        ['MÓDULO 4','MULTIPLICANDO O QUEIJO','Crie processos, métricas e alavancas para escalar receita com consistência.',5],
    ];
    $ids = [];
    $st = db()->prepare('INSERT INTO modules (label,title,description,position) VALUES (?,?,?,?)');
    foreach ($modules as $m) { $st->execute($m); $ids[] = (int)db()->lastInsertId(); }

    // lições: [indice_modulo, titulo, descricao, minutos, posicao]
    $yt = 'https://www.youtube.com/watch?v=dQw4w9WgXcQ';
    $lessons = [
        [0,'O mapa da Fórmula','Entenda a metodologia e prepare seu ambiente para aproveitar cada módulo.',8,1],
        [1,'O instinto que fatura','Como trocar hesitação por observação, velocidade e execução inteligente.',12,1],
        [1,'Antifragilidade comercial','Use erros e rejeições como dados para ficar melhor a cada tentativa.',15,2],
        [2,'Radar de problemas caros','Identifique dores pelas quais pessoas e empresas já pagam para resolver.',14,1],
        [2,'Validação sem achismo','Teste demanda antes de investir tempo e dinheiro demais.',18,2],
        [2,'Seu mapa do queijo','Priorize oportunidades por urgência, margem e facilidade de acesso.',16,3],
        [3,'A oferta irresistível','Monte uma promessa clara, específica e fácil de acreditar.',21,1],
        [3,'Conteúdo que atrai','Crie mensagens que interrompem o scroll e geram desejo.',19,2],
        [3,'Tráfego com intenção','Escolha canais e campanhas alinhados ao comportamento do comprador.',24,3],
        [3,'Fechamento sem pressão','Conduza conversas comerciais com diagnóstico e confiança.',17,4],
        [4,'A matemática do queijo','Domine as métricas que governam lucro, caixa e crescimento.',20,1],
        [4,'Processos que libertam','Transforme tarefas repetidas em sistemas previsíveis.',22,2],
        [4,'Equipe de caçadores','Delegue resultados e construa uma cultura de responsabilidade.',18,3],
        [4,'Escala sustentável','Aumente volume sem sacrificar margem, entrega ou reputação.',26,4],
        [4,'O próximo nível','Defina seu plano de 90 dias e mantenha o crescimento composto.',13,5],
    ];
    $sl = db()->prepare('INSERT INTO lessons (module_id,title,description,video_type,video_url,duration_minutes,position) VALUES (?,?,?,?,?,?,?)');
    foreach ($lessons as $l) {
        $sl->execute([$ids[$l[0]], $l[1], $l[2], 'youtube', $yt, $l[3], $l[4]]);
    }
}

$admin_exists = false;
$schema_ok = false;
try {
    create_schema();
    seed_content();
    $schema_ok = true;
    $admin_exists = (int)q1("SELECT COUNT(*) c FROM users WHERE role='admin'")['c'] > 0;
} catch (Throwable $ex) {
    $step_error = $ex->getMessage();
}

/* 3) Cria o admin */
if ($schema_ok && !$admin_exists && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $name  = trim($_POST['name'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $pass  = $_POST['password'] ?? '';
    if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($pass) < 6) {
        $step_error = 'Preencha nome, um email válido e uma senha de pelo menos 6 caracteres.';
    } else {
        try {
            q('INSERT INTO users (email,password_hash,display_name,role,is_active) VALUES (?,?,?,?,1)',
              [$email, password_hash($pass, PASSWORD_DEFAULT), $name, 'admin']);
            $done = true;
            $admin_exists = true;
        } catch (Throwable $ex) {
            $step_error = 'Não foi possível criar o admin (email já usado?).';
        }
    }
}
?><!DOCTYPE html>
<html lang="pt-BR"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Instalação · A Fórmula do Queijo</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css">
</head><body>
<div class="wrap" style="max-width:560px;margin:0 auto;padding:48px 20px">
  <div class="logo big" style="justify-content:center;margin-bottom:26px">
    <span class="mark">🧀</span>
    <span class="txt"><b>A Fórmula do Queijo</b><span>Instalação</span></span>
  </div>

  <?php if ($step_error): ?>
    <div class="alert alert-error">⚠️ <?= e($step_error) ?></div>
  <?php endif; ?>

  <?php if (!$schema_ok): ?>
    <div class="panel">
      <h3>❌ Banco não conectado</h3>
      <p style="color:var(--muted);line-height:1.6">Abra o arquivo <b>config.php</b> e preencha os dados do banco MySQL
      (DB_NAME, DB_USER, DB_PASS, DB_HOST) que você criou no painel da Hostinger. Depois recarregue esta página.</p>
    </div>

  <?php elseif ($done): ?>
    <div class="panel">
      <h3>✅ Tudo pronto!</h3>
      <p style="color:var(--muted);line-height:1.6">Site instalado com sucesso: tabelas criadas, 5 módulos e 15 aulas de exemplo carregados, e seu administrador criado.</p>
      <p style="color:#ff9b9b;font-size:14px">🔒 <b>Importante:</b> por segurança, apague o arquivo <b>instalar.php</b> do servidor agora.</p>
      <a class="btn btn-gold btn-block" href="login.php">Ir para o Login →</a>
    </div>

  <?php elseif ($admin_exists): ?>
    <div class="panel">
      <h3>✅ Site já instalado</h3>
      <p style="color:var(--muted);line-height:1.6">O banco já está configurado e existe um administrador. Apague o <b>instalar.php</b> por segurança.</p>
      <a class="btn btn-gold btn-block" href="login.php">Ir para o Login →</a>
    </div>

  <?php else: ?>
    <div class="panel">
      <h3>👤 Crie seu acesso de administrador</h3>
      <p style="color:var(--muted);font-size:14px;margin-top:-6px;margin-bottom:18px">Esse será o login para gerenciar módulos, vídeos e alunos.</p>
      <form method="post">
        <div class="field"><label>Seu nome</label><input name="name" required placeholder="Ex: Kayky"></div>
        <div class="field"><label>Email</label><input type="email" name="email" required placeholder="voce@email.com"></div>
        <div class="field"><label>Senha</label><input type="password" name="password" required minlength="6" placeholder="mínimo 6 caracteres"></div>
        <button class="btn btn-gold btn-block">Criar administrador 🧀</button>
      </form>
    </div>
  <?php endif; ?>
</div>
</body></html>
