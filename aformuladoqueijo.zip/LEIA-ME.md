# 🧀 A Fórmula do Queijo — Guia de Instalação (Hostinger)

Plataforma de mentoria com **login**, **área de membros**, **player de vídeo** e **painel administrativo**.
Feita em **PHP + MySQL** — roda direto na sua hospedagem Hostinger, sem mensalidade extra.

---

## ✅ O que você vai precisar
- Sua conta Hostinger com o domínio **aformuladoqueijo.online** (você já tem).
- Acesso ao **hPanel** da Hostinger.
- 10 minutinhos. É simples, siga na ordem.

---

## PASSO 1 — Criar o banco de dados MySQL
1. Entre no **hPanel** da Hostinger.
2. Menu lateral: **Bancos de dados → Bancos de dados MySQL**.
3. Em "Criar um novo banco de dados MySQL", preencha:
   - **Nome do banco**: ex. `formula_queijo`
   - **Usuário**: ex. `formula_user`
   - **Senha**: crie uma senha forte (anote!)
4. Clique em **Criar**.
5. Anote os 4 dados que aparecem:
   - Nome do banco (às vezes vem com prefixo, ex. `u123456789_formula_queijo`)
   - Usuário (ex. `u123456789_formula_user`)
   - Senha (a que você criou)
   - Host (quase sempre **localhost**)

---

## PASSO 2 — Preencher o config.php
1. Abra o arquivo **`config.php`** (na raiz da pasta) em qualquer editor de texto.
2. Preencha SÓ estas 4 linhas com o que você anotou:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_NAME', 'u123456789_formula_queijo');
   define('DB_USER', 'u123456789_formula_user');
   define('DB_PASS', 'SUA_SENHA_DO_BANCO');
   ```
3. Salve o arquivo.

---

## PASSO 3 — Subir os arquivos para o site
1. No hPanel: **Arquivos → Gerenciador de arquivos**.
2. Entre na pasta **`public_html`** (é a pasta pública do seu domínio).
   - Se o domínio estiver como "principal", os arquivos vão direto em `public_html`.
3. Faça upload de **TODO o conteúdo da pasta `aformuladoqueijo`** para dentro de `public_html`.
   - Dica fácil: compacte tudo em `.zip`, envie o zip pelo Gerenciador de Arquivos e use **"Extrair"**.
   - ⚠️ Suba o **conteúdo** da pasta (config.php, index.php, pasta admin, etc.), não a pasta dentro de outra pasta.

---

## PASSO 4 — Instalar (1 clique)
1. No navegador, acesse: **https://aformuladoqueijo.online/instalar.php**
2. A página vai criar as tabelas e já carregar 5 módulos + 15 aulas de exemplo.
3. Preencha **seu nome, email e senha** para criar o **administrador**.
4. Clique em **Criar administrador**.
5. 🔒 **IMPORTANTE:** depois disso, **apague o arquivo `instalar.php`** pelo Gerenciador de Arquivos (segurança).

---

## PASSO 5 — Usar
- **Site / login:** https://aformuladoqueijo.online
- **Painel admin:** https://aformuladoqueijo.online/admin
  - Entre com o email e senha que você criou no passo 4.
  - Lá você **cria módulos**, **adiciona aulas** (upload de vídeo OU link do YouTube/Vimeo), **envia capas** e **libera o acesso dos alunos** (Alunos → Liberar novo acesso).

---

## 🎬 Sobre os vídeos
- **Recomendado:** subir seus vídeos no **YouTube (como "não listado")** ou **Vimeo** e colar o link na aula. Fica mais rápido, leve e não pesa na hospedagem.
- Também dá para **enviar o arquivo .mp4** direto (opção "Enviar arquivo"). Para arquivos grandes, o YouTube/Vimeo é melhor.

---

## 🔐 Segurança já incluída
- Senhas guardadas com criptografia (hash).
- Proteção contra SQL Injection (consultas preparadas).
- Proteção CSRF nos formulários.
- Só quem tem acesso liberado entra; só admin acessa o painel.
- Uploads não conseguem executar scripts.

---

## ❓ Problemas comuns
- **"Erro de conexão com o banco"** → revise os 4 dados no `config.php` (nome, usuário, senha, host). Na Hostinger o host é `localhost`.
- **Página em branco** → confirme que a versão do PHP na Hostinger é **8.0 ou superior** (hPanel → Avançado → Configuração PHP).
- **Vídeo grande não sobe** → use YouTube/Vimeo, ou aumente o limite em hPanel → Configuração PHP.

Qualquer dúvida, é só chamar. Bom queijo! 🧀🐭💰
