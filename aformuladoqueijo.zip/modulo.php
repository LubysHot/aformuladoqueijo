<?php
require_once __DIR__ . '/includes/functions.php';
if (!is_installed()) { redirect(BASE_URL . '/instalar.php'); }
require_active_member();

$u = current_user();
$id = (int)($_GET['id'] ?? 0);
$module = get_module($id);
if (!$module || (!$module['is_published'] && !is_admin())) {
    http_response_code(404); die('Módulo não encontrado.');
}
$lessons = get_lessons($id, !is_admin());
$completed_set = array_flip(get_completed_lessons((int)$u['id']));
$cover = cover_url($module['cover_url']);

$page_title = $module['title'];
$show_topbar = true;
require __DIR__ . '/includes/header.php';
?>
<div class="page">
  <div class="breadcrumb"><a href="<?= e(BASE_URL) ?>/index.php">🏠 Meus Módulos</a> &nbsp;›&nbsp; <?= e($module['title']) ?></div>

  <div class="module-head">
    <div class="cover">
      <div class="module-poster <?= $cover ? '' : 'gen' ?>" style="height:100%">
        <?php if ($cover): ?><img src="<?= e($cover) ?>" alt=""><?php else: ?>
        <div class="content">
          <div class="label"><?= e($module['label'] ?: 'MÓDULO') ?></div>
          <div class="title"><?= e($module['title']) ?></div>
          <div class="author">A FÓRMULA DO QUEIJO</div>
        </div>
        <?php endif; ?>
      </div>
    </div>
    <div>
      <div style="color:var(--gold-2);font-weight:700;letter-spacing:2px;text-transform:uppercase;font-size:12px;margin-bottom:6px"><?= e($module['label'] ?: 'MÓDULO') ?></div>
      <h1><?= e($module['title']) ?></h1>
      <p><?= nl2br(e($module['description'])) ?></p>
    </div>
  </div>

  <div class="section-head"><span class="bar"></span><h2>Aulas deste módulo</h2></div>

  <?php if (!$lessons): ?>
    <div class="empty"><div class="big">🎬</div><p>Nenhuma aula aqui ainda.</p></div>
  <?php else: ?>
  <div class="lesson-list">
    <?php $i=1; foreach ($lessons as $l): $done = isset($completed_set[(int)$l['id']]); ?>
    <a class="lesson-row" href="<?= e(BASE_URL) ?>/aula.php?id=<?= (int)$l['id'] ?>">
      <span class="num <?= $done ? 'done' : '' ?>"><?= $done ? '✓' : $i ?></span>
      <span class="info">
        <b><?= e($l['title']) ?></b>
        <small><?= $l['duration_minutes'] ? (int)$l['duration_minutes'].' min' : 'Aula em vídeo' ?><?= $done ? ' • concluída' : '' ?></small>
      </span>
      <span class="play">▶</span>
    </a>
    <?php $i++; endforeach; ?>
  </div>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
