<?php
require_once __DIR__ . '/includes/functions.php';
if (!is_installed()) { redirect(BASE_URL . '/instalar.php'); }
require_active_member();

$u = current_user();
$id = (int)($_GET['id'] ?? 0);
$lesson = get_lesson($id);
if (!$lesson || (!$lesson['is_published'] && !is_admin())) { http_response_code(404); die('Aula não encontrada.'); }
$module = get_module((int)$lesson['module_id']);
$siblings = get_lessons((int)$lesson['module_id'], !is_admin());

// Marcação automática (chamada via JavaScript quando o vídeo termina)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax_done'])) {
    header('Content-Type: application/json; charset=utf-8');
    if (!isset($_POST['csrf']) || !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'])) {
        echo json_encode(['ok' => false, 'error' => 'csrf']); exit;
    }
    q('INSERT INTO lesson_progress (user_id,lesson_id,completed,completed_at) VALUES (?,?,1,NOW())
       ON DUPLICATE KEY UPDATE completed=1, completed_at=NOW()', [$u['id'], $id]);
    echo json_encode(['ok' => true]); exit;
}

// Marcar como concluída / não concluída (botão manual)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_done'])) {
    csrf_check();
    $existing = q1('SELECT * FROM lesson_progress WHERE user_id=? AND lesson_id=?', [$u['id'], $id]);
    if ($existing && (int)$existing['completed'] === 1) {
        q('UPDATE lesson_progress SET completed=0, completed_at=NULL WHERE user_id=? AND lesson_id=?', [$u['id'], $id]);
    } else {
        q('INSERT INTO lesson_progress (user_id,lesson_id,completed,completed_at) VALUES (?,?,1,NOW())
           ON DUPLICATE KEY UPDATE completed=1, completed_at=NOW()', [$u['id'], $id]);
    }
    redirect(BASE_URL . '/aula.php?id=' . $id);
}

$completed_set = array_flip(get_completed_lessons((int)$u['id']));
$is_done = isset($completed_set[$id]);

$page_title = $lesson['title'];
$show_topbar = true;
require __DIR__ . '/includes/header.php';
?>
<div class="page">
  <div class="breadcrumb">
    <a href="<?= e(BASE_URL) ?>/index.php">🏠 Meus Módulos</a> &nbsp;›&nbsp;
    <a href="<?= e(BASE_URL) ?>/modulo.php?id=<?= (int)$module['id'] ?>"><?= e($module['title']) ?></a> &nbsp;›&nbsp;
    <?= e($lesson['title']) ?>
  </div>

  <div class="player-layout">
    <div>
      <div class="player-box" data-vtype="<?= e($lesson['video_type']) ?>" data-done="<?= $is_done ? '1' : '0' ?>"><?= video_player_html($lesson) ?></div>
      <h1 class="lesson-title"><?= e($lesson['title']) ?></h1>

      <div style="display:flex;gap:12px;flex-wrap:wrap;align-items:center;margin:6px 0 18px">
        <form method="post">
          <?= csrf_field() ?>
          <button id="doneBtn" name="toggle_done" value="1" class="btn <?= $is_done ? 'btn-dark' : 'btn-gold' ?> btn-sm">
            <?= $is_done ? '✓ Concluída (desmarcar)' : 'Marcar como concluída' ?>
          </button>
        </form>
        <span id="autoHint" style="color:var(--muted);font-size:13px">
          <?= $is_done ? '' : 'Marca sozinho ao terminar o vídeo' ?>
        </span>
        <span style="color:var(--muted-2);font-size:13px"><?= $lesson['duration_minutes'] ? (int)$lesson['duration_minutes'].' min' : '' ?></span>
      </div>

      <?php if (trim((string)$lesson['description']) !== ''): ?>
        <p class="lesson-desc"><?= nl2br(e($lesson['description'])) ?></p>
      <?php endif; ?>
    </div>

    <aside class="sidebar-lessons">
      <h3><?= e($module['label'] ?: 'Módulo') ?> · Aulas</h3>
      <?php $i=1; foreach ($siblings as $s): $sd = isset($completed_set[(int)$s['id']]); $active = (int)$s['id']===$id; ?>
        <a class="mini-lesson <?= $active ? 'active' : '' ?>" href="<?= e(BASE_URL) ?>/aula.php?id=<?= (int)$s['id'] ?>">
          <span class="n <?= $sd ? 'done' : '' ?>"><?= $sd ? '✓' : $i ?></span>
          <span><?= e($s['title']) ?></span>
        </a>
      <?php $i++; endforeach; ?>
    </aside>
  </div>
</div>
<div id="afqToast" style="position:fixed;left:50%;bottom:26px;transform:translateX(-50%) translateY(30px);opacity:0;
  background:linear-gradient(135deg,var(--gold-2),var(--gold-deep));color:#151200;font-weight:700;padding:12px 22px;
  border-radius:30px;box-shadow:0 12px 30px rgba(245,197,24,.5);z-index:300;transition:opacity .25s,transform .25s;pointer-events:none">
  ✓ Aula concluída! 🧀
</div>

<script>
(function(){
  var BASE = <?= json_encode(BASE_URL) ?>;
  var LID  = <?= (int)$id ?>;
  var CSRF = <?= json_encode(csrf_token()) ?>;
  var box  = document.querySelector('.player-box');
  if(!box) return;
  var vtype = box.getAttribute('data-vtype');
  var done  = box.getAttribute('data-done') === '1';

  function toast(){
    var t = document.getElementById('afqToast');
    if(!t) return;
    t.style.opacity='1'; t.style.transform='translateX(-50%) translateY(0)';
    setTimeout(function(){ t.style.opacity='0'; t.style.transform='translateX(-50%) translateY(30px)'; }, 3200);
  }
  function onMarked(){
    var b = document.getElementById('doneBtn');
    if(b){ b.classList.remove('btn-gold'); b.classList.add('btn-dark'); b.textContent='✓ Concluída (desmarcar)'; }
    var hint = document.getElementById('autoHint'); if(hint) hint.textContent='';
    var n = document.querySelector('.mini-lesson.active .n'); if(n){ n.classList.add('done'); n.textContent='✓'; }
    toast();
  }
  function markDone(){
    if(done) return; done = true;
    var fd = new FormData();
    fd.append('ajax_done','1'); fd.append('csrf', CSRF);
    fetch(BASE + '/aula.php?id=' + LID, { method:'POST', body:fd, credentials:'same-origin' })
      .then(function(r){ return r.json(); })
      .then(function(res){ if(res && res.ok){ onMarked(); } else { done=false; } })
      .catch(function(){ done=false; });
  }
  function loadScript(src, cb){
    var s=document.createElement('script'); s.src=src; s.async=true; if(cb) s.onload=cb;
    document.head.appendChild(s);
  }

  if(done) return; // já concluída, não precisa observar

  if(vtype === 'upload' || vtype === 'direct'){
    var v = document.getElementById('afqPlayer');
    if(v){
      v.addEventListener('timeupdate', function(){
        if(v.duration && isFinite(v.duration) && v.currentTime >= v.duration - 2){ markDone(); }
      });
      v.addEventListener('ended', markDone);
    }
  } else if(vtype === 'youtube'){
    // API de iframe do YouTube -> detecta o fim (estado ENDED)
    window.onYouTubeIframeAPIReady = function(){
      try{
        new YT.Player('afqPlayer', { events: { onStateChange: function(e){
          if(e.data === YT.PlayerState.ENDED){ markDone(); }
        }}});
      }catch(err){}
    };
    if(window.YT && window.YT.Player){ window.onYouTubeIframeAPIReady(); }
    else{ loadScript('https://www.youtube.com/iframe_api'); }
  } else if(vtype === 'vimeo'){
    loadScript('https://player.vimeo.com/api/player.js', function(){
      try{
        var p = new Vimeo.Player('afqPlayer');
        p.on('ended', markDone);
        p.on('timeupdate', function(d){ if(d && d.percent >= 0.97){ markDone(); } });
      }catch(err){}
    });
  }
})();
</script>
<?php require __DIR__ . '/includes/footer.php'; ?>
